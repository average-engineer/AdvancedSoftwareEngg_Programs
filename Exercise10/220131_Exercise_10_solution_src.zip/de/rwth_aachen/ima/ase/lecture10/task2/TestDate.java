package de.rwth_aachen.ima.ase.lecture10.task2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDate {
	@Test
	public void testAddDays() {
		Date d = new Date(2020, 1, 13);
		d.addDays(100);
		assertEquals(22, d.getDay());
		assertEquals(4, d.getMonth());
		assertEquals(2020, d.getYear());
	}
	
	@Test
	public void testCreateDate() {
		Date d = new Date(2020,1,32);
		assertEquals(1,d.getDay());
		assertEquals(2, d.getMonth());
		assertEquals(2020, d.getYear());
	}
	
	@Test
	public void testNextDay() {
		Date d = new Date(2020,2,28);
		d.nextDay();
		assertEquals(29, d.getDay());
		assertEquals(2,d.getMonth());
		assertEquals(2020,d.getYear());
	}

}
