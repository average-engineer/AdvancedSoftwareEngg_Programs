package de.rwth_aachen.ima.ase.lecture10.task4;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestLine {

	private static final double EPS = 0.000001;
	
	@Test
	public void testGetSlopeWithoutException() {
		Line line1 = new Line(2.0, 1.0, 4.0, 1.0);
		assertEquals("Slope of zero", 0.0, line1.getSlope(), EPS);
		
		Line line2 = new Line(2.0,1.0, 4.0,2.0);
		assertEquals(0.5, line2.getSlope(), EPS);
		
		Line line3 = new Line(2.0,1.0, 3.0,3.0);
		assertEquals(2.0, line3.getSlope(), EPS);
		
		Line line4 = new Line(2.0,1.0, 1.0,3.0);
		assertEquals(-2.0, line4.getSlope(), EPS);
	}
	
	@Test
	public void testGetDsitance() {
		Line line1 = new Line(2.0,1.0, 2.0,1.0);
		assertEquals("Zero Distance", 0.0, line1.getDistance(), EPS);
		
		Line line2 = new Line(2.0,1.0,3.0,1.0);
		assertEquals("Distance based on x", 1.0, line2.getDistance(), EPS);
		
		Line line3 = new Line(2.0,1.0, 2.0,2.0);
		assertEquals("Distance based on y", 1.0, line3.getDistance(), EPS);
		
		Line line4 = new Line(2.0,2.0, 3.0,3.0);
		assertEquals("Distance based on x and y", Math.sqrt(2.0), line4.getDistance(), EPS);
	}
	
	@Test
	public void testParallelTo() {
		Line line1 = new Line(2.0,1.0, 5.0,1.0);
		Line line2 = new Line(2.0,1.0, 5.0,1.0);
		assertTrue("Equal lines", line1.parallelTo(line2));
		
		Line line3 = new Line(2.0,4.0, 5.0,4.0);
		assertTrue("Moved y", line1.parallelTo(line3));
		
		Line line4 = new Line(3.0,4.0, 7.0,4.0);
		assertTrue("Moved x and y", line1.parallelTo(line4));
		
		Line line5 = new Line(3.0,4.0,7.0,6.0);
		assertFalse("Changed slope", line1.parallelTo(line5));
	}
	
	@Test(expected=ArithmeticException.class)
	public void testGetSlopeWithException() {
		Line line = new Line(1.0,1.0,1.0,1.0);
		line.getSlope();
	}
		
	@Test
	public void testGetSlopeWithException_manually() {
		Line line = new Line(1.0,1.0,1.0,1.0);
		try {
			line.getSlope();
		}catch(ArithmeticException e) {
			return;
		}catch(Exception e) {
			fail("Wrong exception was thrown");
		}
	}

}
