package de.rwth_aachen.ima.ase.lecture10.task1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestMyPoint {

	private static final double EPS = 0.0001;
	
	private static final double SQRT72 = Math.sqrt(72.0);
	
	private static final double SQRT2 = Math.sqrt(2.0);
	
	@Test
	public void testDistanceIntParams() {
		MyPoint p = new MyPoint(0, 0);
		assertEquals("Equal distance", 0.0, p.distance(0, 0), EPS);
		assertEquals("Distance based on x", 1.0, p.distance(1, 0), EPS);
		assertEquals("Distance based on y", 1.0, p.distance(0, 1), EPS);
		assertEquals("Distance based on x and y", SQRT72, p.distance(6, 6), EPS);
	}

	@Test
	public void testDistancePointParam() {
		MyPoint p = new MyPoint(0,0);
		MyPoint d = new MyPoint(0,0);
		assertEquals("Equal distance", 0.0, p.distance(d), EPS);
		d.setX(1);
		assertEquals("Distance based on x", 1.0, p.distance(d), EPS);
		d.setX(0);
		d.setY(1);
		assertEquals("Distance based on y", 1.0, p.distance(d), EPS);
		d.setX(1);
		assertEquals("Distance based on x and y", SQRT2, p.distance(d), EPS);
	}
	
	@Test
	public void testToString() {
		MyPoint p = new MyPoint(0,0);
		assertEquals("(0,0)", p.toString());
	}
	
}
