package de.rwth_aachen.ima.ase.lecture10.task1;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyPointTest {
	
	private static final double EPS = 0.0001;
	private static final double SQRT72 = Math.sqrt(72.0);
	private static final double SQRT8 = Math.sqrt(8.0);
	
	MyPoint p = new MyPoint(0,0);

	@Test
	public void testDistanceIntParams() {
		assertEquals("Equal distance", 0.0, p.distance(0,0), EPS);
		assertEquals("Distance based on x", 1.0, p.distance(1,0), EPS);
		assertEquals("Disntace based on y", 2.0, p.distance(0,2), EPS);
		assertEquals("Distance based on x and y", SQRT72 ,p.distance(6,6), EPS);
	}
	
	@Test
	public void testDistancePointParam() {
		MyPoint d = new MyPoint(0,0);
		
		assertEquals("Equal distance", 0.0, p.distance(d), EPS);
		d.setX(5);
		assertEquals("Distance based on x", 5.0, p.distance(d), EPS);
		d.setX(0);
		d.setY(2);
		assertEquals("Disntace based on y", 2.0, p.distance(d), EPS);
		d.setX(2);
		assertEquals("Distance based on x and y", SQRT8 ,p.distance(d), EPS);
	}
	
	
	
	@Test
	public void testToString() {
		assertEquals("(0,0)", p.toString());
	}

}
