package de.rwth_aachen.ima.ase.lecture10.task5;

import static org.junit.Assert.*;

import org.junit.Test;

import de.rwth_aachen.ima.ase.lecture10.task1.MyPoint;

public class TestMyCircle {

	private static final double EPS = 0.0001;

	@Test
	public void testGetArea() {
		MyCircle c = new MyCircle(0, 0, 1);
		assertEquals("Unit circle", Math.PI, c.getArea(), EPS);
		MyCircle p = new MyCircle(0, 0, 0);
		assertEquals("No radius", 0.0, p.getArea(), EPS);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSetCenterWithException() {
		MyCircle c = new MyCircle(0, 0, 1);
		c.setCenter(null);
	}

	@Test
	public void testSetCenterWithoutException() {
		MyCircle c = new MyCircle(0, 0, 1);
		c.setCenter(new MyPoint(1, 2));
		assertEquals("x-value check", 1, c.getCenterX());
		assertEquals("y-value check", 2, c.getCenterY());
	}

	@Test
	public void testToString() {
		MyCircle c = new MyCircle(0, 0, 1);
		assertEquals("Syntax check", "Circle @ (0,0) radius=1", c.toString());
	}

}
